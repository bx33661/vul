<html>
    <head>
        <style type="text/css">
        * {
            //Common Style for All Elements
        }
        body {

        }
        .header {
            background-image: url("image/top_bg_01.gif");
            height:84px;
            width: 965px;
        }
        .container {
            /*background-color: green;*/
            border: 1px solid;
            height: 200px;
            width: 965px; 
        }
        .container p {
            position: relative;
            left: 20px;
            padding: 10px 0;
        }
        </style>
    </head>

    <body>

        <div class="header">
            <img src="image/top_LG_NAS_Storage.gif" height="85px" width="282px" />
        </div>

        <div class="container">
            <h2>User Web Service started</h2>
            <h2>LG NAS Management Page URL - <a href="http://<?php echo $_SERVER['SERVER_NAME'];?>:8000">http://<?php echo $_SERVER['SERVER_NAME'];?>:8000</a></h2>
            <p><p>
        </div>

    </body>
</html>
